﻿namespace BigMamma
{
    public class Program
    {
        static void Main(string[] args)
        {
            Store store = new Store("Maglekærvej 7", "Big Mamma pizza", 231321421) ;
            store.start();  
        }
    }
}